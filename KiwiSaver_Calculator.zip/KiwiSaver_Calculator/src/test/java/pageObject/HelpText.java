package pageObject;

import utilities.DriverManager;

public class HelpText extends DriverManager {
	// Navigation flow KiwiSaver
	public String navKiwiSaver = "//a[@id='ubermenu-section-link-kiwisaver-ps']";
	public String helpSectionLoading = "//header/div[1]/nav[3]/ul[1]/li[6]/div[1]/ol[1]/li[2]/ul[1]/li[1]";
	public String btnKiwiSaver_Calc = "//a[@id='ubermenu-item-cta-kiwisaver-calculators-ps']";

	public String pgArticleHeading = "//h1[contains(text(),'Westpac KiwiSaver Scheme Risk Profiler and Retirem')]";
	public String btnGetStarted = "//a[contains(text(),'Click here to get started.')]";
	public String pgCalcHeader = "//h1[contains(text(),'KiwiSaver Retirement Calculator')]";

	public String btnIcon1 = "//body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/button[1]/i[1]";
	public String btnIcon2 = "//body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/button[1]";
	public String btnIcon3 = "//body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/button[1]/i[1]";
	public String btnIcon4 = "//body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/button[1]/i[1]";
	public String btnIcon5 = "//body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[5]/div[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/button[1]/i[1]";
	public String btnIcon6 = "//body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[6]/div[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/button[1]/i[1]";

	public String msgAgeTooltip = "//p[contains(text(),'This calculator has an age limit of 18 to 64 years')]";

}