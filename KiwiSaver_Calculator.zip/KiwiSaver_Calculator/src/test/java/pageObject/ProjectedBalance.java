package pageObject;

import org.openqa.selenium.By;

import org.openqa.selenium.WebElement;

import utilities.DriverManager;

public class ProjectedBalance extends DriverManager {
//current age
	public String currentAge = "//input[@type='text']";

//salary
	public String sal = "//body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/input[1]";

//employee status
	public String empStatus = "//body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]";

//Method to find employment status
	public void selectemploymentStausbyText(String employstatustext) {
		java.util.List<WebElement> EmploymentStatus = driver
				.findElements(By.cssSelector("ul.option-list li div.label span"));
		for (int i = 0; i < EmploymentStatus.size(); i++) {
			System.out.println(EmploymentStatus.get(i).getText());
			if (EmploymentStatus.get(i).getText().contains(employstatustext)) {
				EmploymentStatus.get(i).click();
				break;
			}
		}
	}

//Member Contribution to KiwiSaver
	public String memContri = "//input[@id='radio-option-04F']";

//RiskProfile
	public String defensiveRiskProfile = "//input[@id='radio-option-013']"; // Defensive

	public String conservativeRiskProfile = "//input[@id='radio-option-016']"; // conservative

	public String balanceRiskProfile = "//input[@id='radio-option-019']"; // Balance
//KiwiBalance

	public String kiwibalance = "//body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/input[1]";

//Voluntary contributions
	public String vContributions = "//body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/input[1]";

//Frequency
	public String freqDropdown = "//body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]";

	// Method to Select Frequency
	public void selectVoluntaryContributionFrequency(String frequency) {
		java.util.List<WebElement> Frequencies = driver.findElements(By.xpath(
				"//div[contains(@class,'wpnib-field-voluntary-contributions field-group ng-isolate-scope')]//li"));
		System.out.println("size:" + Frequencies.size());
		for (int i = 0; i < Frequencies.size(); i++) {
			System.out.println(Frequencies.get(i).getText());
			if (Frequencies.get(i).getText().contains(frequency)) {
				Frequencies.get(i).click();
				break;
			}
		}

	}

//Saving goals requirement

	public String savingGoal = "//*[@id=\"widget\"]/div/div[1]/div/div[1]/div/div[6]/div/div/div/div[2]/div[1]/div[1]/div/div/div[1]/div/div/input";

//Complete Form
	public String completeForm = "//body/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/button[1]";

//view estimated balance
	public String estimatedBalance = "//*[@id=\"widget\"]/div/div[1]/div/div[3]/div/div[1]/div[1]/div[1]/span[1]";

//Balance Summary

	public String balanceSummary = "//*[@id=\"widget\"]/div/div[1]/div/div[3]/div/div[1]/div[1]/div[2]/div[1]/div[1]";

}
