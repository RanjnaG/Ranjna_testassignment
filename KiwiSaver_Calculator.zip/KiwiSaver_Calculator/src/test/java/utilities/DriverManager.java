
package utilities;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.safari.SafariDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DriverManager {
	public static WebDriver driver;
	public static Properties prop;

	public WebDriver getDriver() throws IOException {

		prop = new Properties();

		// Data from Global Configuration file(Example- URL)

		FileInputStream fis = new FileInputStream(
				System.getProperty("user.dir") + "/src/test/java/utilities/GlobalConfig.properties");

		prop.load(fis);

		String browser = prop.getProperty("Browser");

		if (browser.equals("googlechrome")) {

			WebDriverManager.chromedriver().setup();

			driver = new ChromeDriver();

		}

		

		driver.get(prop.getProperty("BaseUrl"));

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);

		return driver;

	}

}
