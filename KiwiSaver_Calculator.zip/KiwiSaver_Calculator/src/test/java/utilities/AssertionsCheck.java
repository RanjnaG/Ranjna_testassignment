package utilities;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;

public class AssertionsCheck extends DriverManager {

	public boolean verifyElementPresent(String locator) throws Exception {

		boolean visible = driver.findElement(By.xpath(locator)).isDisplayed();
		boolean result = visible;
		System.out.println(result);
		return result;
	}

	public void verifyAssertEqual(String expectedText, String actualText) throws Exception {

		try {
			assertEquals(expectedText, actualText);

			System.out.println("Text is matched");
		} catch (Exception e) {
			System.out.println("Text is not matched");
		}
	}

}
