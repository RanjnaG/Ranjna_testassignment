//Ranjna Gupta
package stepDefination;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageObject.HelpText;
import utilities.AssertionsCheck;
import utilities.DriverManager;

public class HelpTextSteps extends DriverManager {
	HelpText tooltip = new HelpText();
	DriverManager drivermanager = new DriverManager();
	AssertionsCheck astCheck = new AssertionsCheck();

	public WebDriver driver;

	@Given("^I open up westpac website and navigate to kiwisaver calculator$")
	public void i_open_up_westpac_website_and_navigate_to_kiwisaver_calculator() throws Throwable {
		// initiate the browser
		WebDriver driver = drivermanager.getDriver();
		this.driver = driver;

		// Navigate to kiwisaver calculate
		driver.findElement(By.xpath(tooltip.navKiwiSaver)).click();

		driver.navigate().to("https://www.westpac.co.nz/kiwisaver/calculators/");

		driver.findElement(By.xpath(tooltip.btnGetStarted)).click();

		driver.switchTo().frame(driver.findElement(By.xpath("//div[@id='calculator-embed']/iframe[1]")));

	}

	@Then("^all fields in the calculator have got the information icon present$")
	public void all_fields_in_the_calculator_have_got_the_information_icon_present() throws Throwable {

		// Assertion -> element present
		astCheck.verifyElementPresent(tooltip.btnIcon1);
		astCheck.verifyElementPresent(tooltip.btnIcon2);
		astCheck.verifyElementPresent(tooltip.btnIcon3);
		astCheck.verifyElementPresent(tooltip.btnIcon4);
		astCheck.verifyElementPresent(tooltip.btnIcon5);
		astCheck.verifyElementPresent(tooltip.btnIcon6);

		System.out.println("Check for an element");

	}

	@When("^I click info icon displaying beside the the field current age$")

	public void i_click_info_icon_displaying_beside_the_the_field_current_age() throws Throwable {

		// Click on the tooltip Age icon
		driver.findElement(By.xpath(tooltip.btnIcon1)).click();

		System.out.println("clicked on button");
	}

	@Then("^information message is displayed below the current age field$")
	public void information_message_is_displayed_below_the_current_age_field() throws Throwable {

		String actualText = driver.findElement(By.xpath(tooltip.msgAgeTooltip)).getText();

		String expectedText = "This calculator has an age limit of 64 years old as you need to be under the age of 65 to join KiwiSaver";

		astCheck.verifyAssertEqual(expectedText, actualText);
	}

}