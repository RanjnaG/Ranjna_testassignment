//Ranjna Gupta

package stepDefination;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import cucumber.api.java.en.And;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageObject.ProjectedBalance;
import utilities.AssertionsCheck;
import utilities.DriverManager;

public class CalculateProjectedBalance extends DriverManager {
	ProjectedBalance pb = new ProjectedBalance();
	AssertionsCheck astCheck = new AssertionsCheck();

	// High Risk Profile User whose Current age is 30 is Employed at a Salary 82000 p/a, contributes
	// to KiwiSaver at 4% and chooses a Defensive risk profile

	@When("^I enter current age(.+), employment status(.+), salary(.+), contributions(.+), and risk profile(.+)$")
	public void i_enter_current_age_employment_status_salary_contributions_and_risk_profile(String age,
			String empstatus, String sal, String contributions, String riskprofile) throws Throwable {
		driver.findElement(By.xpath(pb.currentAge)).sendKeys(age);
		driver.findElement(By.xpath(pb.empStatus)).click();
		pb.selectemploymentStausbyText("Employed");
		driver.findElement(By.xpath(pb.sal)).sendKeys(sal);
		driver.findElement(By.xpath(pb.memContri)).click();
		driver.findElement(By.xpath(pb.defensiveRiskProfile)).click();
	}

	@And("^I click View your KiwiSaver retirement projections button$")
	public void i_click_view_your_kiwisaver_retirement_projections_button() throws Throwable {
		driver.findElement(By.xpath(pb.completeForm)).click();

	}

	@Then("^my estimated Kiwisaver balance at age 65 is calculated and displayed with instructions$")
	public void my_estimated_kiwisaver_balance_at_age_65_is_calculated_and_displayed_with_instructions()
			throws Throwable {
		// Estimated Balance
		driver.findElement(By.xpath(pb.estimatedBalance)).isEnabled();
		String actualText = driver.findElement(By.xpath(pb.estimatedBalance)).getText();

		// Balance Summary
		driver.findElement(By.xpath(pb.balanceSummary)).isEnabled();

		String actualText1 = driver.findElement(By.xpath(pb.balanceSummary)).getText();

	}

	// Self-Employed User whose Current age is 45 at a Salary 100000 p/a,
	// voluntary contributes $90
	// fortnightly and chooses Conservative risk profile with saving goals
	// requirement of $290000

	@When("^I enter current age(.+), employment status(.+), kiwibalance(.+), Voluntary contributions(.+), "
			+ "frequency(.+), risk profile(.+), saving goals(.+)$")

	public void i_enter_current_age_employment_status_kiwibalance_voluntary_contributions_frequency_risk_profile_saving_goals

	(String age, String empstatus, String kiwibalance, String volcontributions, String freq, String riskprofile,
			String savinggoals) throws Throwable {

		driver.findElement(By.xpath(pb.currentAge)).sendKeys(age);
		driver.findElement(By.xpath(pb.empStatus)).click();
		pb.selectemploymentStausbyText("Self-employed");
		driver.findElement(By.xpath(pb.kiwibalance)).sendKeys(kiwibalance);
		driver.findElement(By.xpath(pb.vContributions)).sendKeys(volcontributions);
		driver.findElement(By.xpath(pb.freqDropdown)).click();
		pb.selectVoluntaryContributionFrequency(freq);
		driver.findElement(By.xpath(pb.conservativeRiskProfile)).click();
		driver.findElement(By.xpath(pb.savingGoal)).sendKeys(savinggoals);

	}

	@And("^I click to View your KiwiSaver retirement projections > button$")

	public void i_click_to_view_your_kiwisaver_retirement_projections_button() throws Throwable {

		driver.findElement(By.xpath(pb.completeForm)).click();

	}

	@Then("^estimated Kiwisaver balance at age 65 is calculated and displays with instructions$")

	public void estimated_kiwisaver_balance_at_age_65_is_calculated_and_displays_with_instructions() throws Throwable {

		// Estimated Balance
		driver.findElement(By.xpath(pb.estimatedBalance)).isEnabled();
		String actualText = driver.findElement(By.xpath(pb.estimatedBalance)).getText();

		// Balance Summary
		driver.findElement(By.xpath(pb.balanceSummary)).isEnabled();

		String actualText1 = driver.findElement(By.xpath(pb.balanceSummary)).getText();

	}

	// Not Employed User whose Current age is 55, current KiwiSaver balance is
	// $140000,
	// voluntary contributes $10 annually and chooses Balanced risk profile with
	// saving goals requirement
	// of $200000 can calculate his projected balances at retirement

	@When("^I enter my current age(.+), employment status(.+), kiwibalance(.+), Voluntary contributions(.+), "
			+ "frequency(.+), risk profile(.+), saving goals(.+)$")
	public void i_enter_my_current_age_employment_status_kiwibalance_voluntary_contributions_frequency_risk_profile_saving_goals(
			String age, String empstatus, String kiwibalance, String volcontributions, String freq, String riskprofile,
			String savinggoals) throws Throwable {

		driver.findElement(By.xpath(pb.currentAge)).sendKeys(age);
		driver.findElement(By.xpath(pb.empStatus)).click();
		pb.selectemploymentStausbyText("Self-employed");
		driver.findElement(By.xpath(pb.kiwibalance)).sendKeys(kiwibalance);
		driver.findElement(By.xpath(pb.vContributions)).sendKeys(volcontributions);
		driver.findElement(By.xpath(pb.freqDropdown)).click();
		pb.selectVoluntaryContributionFrequency(freq);
		driver.findElement(By.xpath(pb.balanceRiskProfile)).click();
		driver.findElement(By.xpath(pb.savingGoal)).sendKeys(savinggoals);

	}

	@And("^I click and View your KiwiSaver retirement projections > button$")
	public void i_click_and_view_your_kiwisaver_retirement_projections_button() throws Throwable {
		driver.findElement(By.xpath(pb.completeForm)).click();

	}

	@Then("^estimated Kiwisaver balance at age 65 is calculated and display with instructions$")
	public void estimated_kiwisaver_balance_at_age_65_is_calculated_and_display_with_instructions() throws Throwable {

		// Estimated Balance
		driver.findElement(By.xpath(pb.estimatedBalance)).isEnabled();
		String actualText = driver.findElement(By.xpath(pb.estimatedBalance)).getText();

		// Balance Summary
		driver.findElement(By.xpath(pb.balanceSummary)).isEnabled();

		String actualText1 = driver.findElement(By.xpath(pb.balanceSummary)).getText();

	}

}