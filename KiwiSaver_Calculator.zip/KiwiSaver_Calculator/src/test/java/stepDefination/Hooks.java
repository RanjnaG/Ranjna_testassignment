//Ranjna Gupta

package stepDefination;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import cucumber.api.Scenario;
import cucumber.api.java.After;

import utilities.DriverManager;

public class Hooks {
	// Logger log= Logger.getLogger(Hooks.class);

	@After
	public void afterScenario(Scenario scenario) {

		WebDriver driver = DriverManager.driver;

		if (scenario.isFailed()) {
			try {
				// Logger.info(scenario.getName() + " is failed");

				final byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
				scenario.embed(screenshot, "image/png");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		driver.close();

	}

}
